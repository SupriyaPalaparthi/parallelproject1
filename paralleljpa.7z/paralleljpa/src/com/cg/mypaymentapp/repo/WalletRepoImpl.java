package com.cg.mypaymentapp.repo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.mypaymentapp.beans.Customer;


public class WalletRepoImpl implements WalletRepo {

	EntityManager manager;
	 public WalletRepoImpl() {
		 

	EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAQ");
	manager =emf.createEntityManager();
	 }
		
	
	@Override
	public boolean save(Customer customer) {
		
		if(customer!=null){
		manager.getTransaction().begin();//to begin the transaction
		manager.persist(customer);//it is used with respect to the entity manager
		manager.getTransaction().commit();//commitment of the transaction
		return true;
		}
		
		return false;
	
	}
	@Override
	public Customer findOne(String mobileNo) {
		
		Customer mobSearch=manager.find(Customer.class, mobileNo);
		
		return mobSearch;
		
	}
	
}
