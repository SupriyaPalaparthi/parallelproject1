package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;

import com.cg.mypaymentapp.beans.Customer;

@SuppressWarnings("unused")
public interface WalletRepo {
	
	public boolean save(Customer customer);//to save the data in database connection
	
	public Customer findOne(String mobileNo);//to search the mobile number
	
	
}
