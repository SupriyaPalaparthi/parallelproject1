package com.cg.mypaymentapp.exception;

@SuppressWarnings("serial")
public class InvalidInputException extends Exception {

	public InvalidInputException(String msg) {
		super(msg);
		//System.out.println(" Invalid input");
	}
}
