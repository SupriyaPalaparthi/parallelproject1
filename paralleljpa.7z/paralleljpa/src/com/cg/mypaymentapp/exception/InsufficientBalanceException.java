package com.cg.mypaymentapp.exception;

@SuppressWarnings("serial")
public class InsufficientBalanceException extends Exception{

	public InsufficientBalanceException(String msg) {
		super(msg);
		//System.out.println("Your balance is Insufficient in the account");
	}
}
