package com.cg.mypaymentapp.main;

import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Client {
	static Scanner sc;
	public static void main(String[] args) throws InvalidInputException {
		
		WalletService service=new WalletServiceImpl();
		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int ch=0;
		
		do{
			System.out.println(" 1.Create Account");
			System.out.println(" 2.Show Balance");
			System.out.println(" 3.Deposit Money");
			System.out.println(" 4.Withdraw Money");
			System.out.println(" 5.Fund Transfer");
			System.out.println(" 6.Exit");
			
			System.out.println("\nSelect an option :\n");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				System.out.println("Enter Your Mobile Number");
				String custMobNo=sc.next();
				
					try {
					if(service.ValidateMobNo(custMobNo)==false)
						throw new InvalidInputException("Enter a 10 digit number");
					} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
					break;
					}
				System.out.println("Enter Your Name");
				String custName=sc.next();
					try {
					if(service.ValidateName(custName)==false)
						throw new InvalidInputException("Enter a valid name starting with capital letter");
					} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
						System.out.println(e1.getMessage());
						break;
					}
				
				System.out.println("Enter the amount you want to add");
				float money=sc.nextFloat();
				try {
					if(service.ValidateAmount(money)==false)
					System.out.println("Enter money greater than zero ");
				} catch (InvalidInputException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
					break;
				}
						
			
				Customer cust = null;
				
				try{
				if(service.checkAccount(custMobNo)==null){
				
				cust = service.createAccount(custMobNo,custName, money);
			
					if(cust==null)
					try {
						throw new InvalidInputException("File didnot added");
					} catch (InvalidInputException e1) {
						// TODO Auto-generated catch block
						System.out.println(e1.getMessage());
					}
				System.out.println(cust);
				System.out.println("Record added successfully");
				
				}	}
				catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			
				
				break;
			
			case 2:
				System.out.println("Enter your mobile number");
				String custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
						Customer customer=service.showBalance(custMobNo1);
						
							
							System.out.println(customer);
									
						}
					else
						throw new InvalidInputException("Enter a 10 digit number");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				
				
				break;
				
			
				case 3:
				System.out.println("Enter your mobile number");
				custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
					 Customer customer=service.showBalance(custMobNo1);
					 
					// System.out.println(customer);
					 System.out.println("Enter the amount you want to deposit ");
					 float dep=sc.nextFloat();
					 customer=service.depositAmount(custMobNo1, dep);
					 
					 System.out.println(" Your updated balance is "+customer.getBalance() );
					}
					else
						throw new InvalidInputException("Enter a 10 digit number");
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
					
				 break;
				 
				case 4:
				System.out.println(" Enter your mobile number");
				custMobNo1=sc.next();
				try {
					if(service.ValidateMobNo(custMobNo1)){
					 Customer customer=service.showBalance(custMobNo1);
					
					// System.out.println(customer);
					 System.out.println(" Enter the amount you want to withdraw ");
					 float withdraw=sc.nextFloat();
					 try {
						customer=service.withdrawAmount(custMobNo1, withdraw);
					} catch (InsufficientBalanceException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
					
					 System.out.println(" Your updated balance is "+customer.getBalance() );
					}
					else 
						throw new InvalidInputException("Enter a 10 digit number");
				} catch (InvalidInputException e) {
						System.out.println(e.getMessage());
				
				}
				 break;
				 
				 
			case 5:
				System.out.println("Enter your mobile number");
				String custMobNoS=sc.next();
				try {
					if(service.ValidateMobNo(custMobNoS)){
						Customer customer=service.showBalance(custMobNoS);
						
						//System.out.println(customer);
						System.out.println("Enter the mobile number to which you want to transfer the money ");
						String custMobNoT=sc.next();
						if(service.ValidateMobNo(custMobNoT)){
						System.out.println("Enter the amount to be transferred ");
						
						float ft=sc.nextFloat();
					 
						customer=service.fundTransfer(custMobNoS, custMobNoT, ft);
						
						System.out.println(customer);
						System.out.println("Transferred successfully");
					} }
					else
						try {
							throw new InvalidInputException("Enter a 10 digit number");
						} catch (InvalidInputException e) {
							System.out.println(e.getMessage());
						
						}
				} catch (InvalidInputException e) {
					System.out.println(e.getMessage());
					
				}
				
				 break;
			}
			
		}while(ch!=7);
		
	}
}
