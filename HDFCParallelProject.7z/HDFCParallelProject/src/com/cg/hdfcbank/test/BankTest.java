package com.cg.hdfcbank.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.hdfcbank.service.BankServiceImpl;


public class BankTest {
	
	@Test
	public void ValidateNameTrue(){
		BankServiceImpl m = new BankServiceImpl();
		assertEquals(true, m.validateUserName("Supriya"));
	}
	
	@Test
	public void ValidatePhonNumberTrue(){
		BankServiceImpl m = new BankServiceImpl();
		assertEquals(true, m.validatePhoneNumber("9966922993"));
	}
	
	@Test
	public void ValidatePhoneNumber(){
		BankServiceImpl m = new BankServiceImpl();
		assertEquals(false, m.validatePhoneNumber("963258417"));
		assertEquals(false, m.validatePhoneNumber("5632584170"));
		assertEquals(false, m.validatePhoneNumber("584170"));
		assertEquals(false, m.validatePhoneNumber("testing"));
		assertEquals(false, m.validatePhoneNumber("@#%^*"));
	}
	
	@Test 
	public void ValidateNameV2(){
		BankServiceImpl m = new BankServiceImpl();
		assertEquals(false, m.validateUserName("priya123"));
		assertEquals(false, m.validateUserName("supriya@1234"));
		assertEquals(false, m.validateUserName("6348513"));
		assertEquals(false, m.validateUserName("hgygdsdf"));
	}
	
	@Test
	public void ValidateAmountTrue(){
		BankServiceImpl m = new BankServiceImpl();
		assertEquals(true, m.validateAmount(100));
	}
	
	@Test 
	public void ValidateAmount(){
		BankServiceImpl m = new BankServiceImpl();
		assertEquals(false, m.validateAmount(0));
		assertEquals(false, m.validateAmount(-400));
	}
	
}
