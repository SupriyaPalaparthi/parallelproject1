package com.cg.hdfcbank.service;

import com.cg.hdfcbank.dto.Customer;
import com.cg.hdfcbank.exception.BankException;
import com.cg.hdfcbank.exception.InvalidAmount;
import com.cg.hdfcbank.exception.InvalidPhoneNumber;

public interface BankService {
	
	public Customer createAccount(Customer c);
	public double showBalance (String mobileno) throws InvalidPhoneNumber;
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, double amount) throws BankException;
	public Customer depositAmount (String mobileNo, double amount ) throws InvalidPhoneNumber, InvalidAmount;
	public Customer withdrawAmount(String mobileNo, double amount) throws BankException;
	public boolean validateUserName(String name);
	public boolean validatePhoneNumber(String mobNo);
	public boolean validateTargetMobNo(String targetMobNo);
	public boolean validateAmount(double amt);
	public boolean validateAll(Customer c);
	
	

}
