package com.cg.hdfcbank.dao;

import com.cg.hdfcbank.dto.Customer;
import com.cg.hdfcbank.exception.BankException;

public interface BankDao {
	
	public Customer createAccount(Customer c);
	public double showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, double amount) throws BankException;
	public Customer depositAmount (String mobileNo, double amount );
	public Customer withdrawAmount(String mobileNo, double amount) throws BankException;

}
