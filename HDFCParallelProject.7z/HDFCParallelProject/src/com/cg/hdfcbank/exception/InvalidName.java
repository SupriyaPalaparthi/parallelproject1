package com.cg.hdfcbank.exception;

@SuppressWarnings("serial")
public class InvalidName extends Exception{
	public InvalidName() {
		// TODO Auto-generated constructor stub
		System.out.println("*****Invalid Name declaration*****" + "First letter should be capital remaining should be small letter... :)");
	}
}
