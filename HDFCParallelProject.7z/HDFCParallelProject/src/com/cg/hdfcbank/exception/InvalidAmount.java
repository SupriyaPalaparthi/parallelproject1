package com.cg.hdfcbank.exception;

@SuppressWarnings("serial")
public class InvalidAmount extends Exception{
	public InvalidAmount() {
			System.out.println("*****Invalid Amount*****" + "Amount can't be negative..." + "Amount can't be zero :)");
	}
}