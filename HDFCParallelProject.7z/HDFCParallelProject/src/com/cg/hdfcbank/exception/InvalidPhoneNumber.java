package com.cg.hdfcbank.exception;

@SuppressWarnings("serial")
public class InvalidPhoneNumber extends Exception {
	public InvalidPhoneNumber() {
		// TODO Auto-generated constructor stub
		System.out.println("*****Invalid Phone Number*****\n"
				+ "Mobile Number should be of length 10 digits\n"
				+ "It should not consists of any special characters or alphabets :)");
	}
}
